numRegs = 32

class TomasuloEngine:
    """
    Simple Tomasulo algorithm simulator.
    Uses dicts and lists for academic simplicity.
    """
    
    def __init__(self):
        # Latencies for each operation
        self.LATENCIES = {
            'ADD': 2,
            'SUB': 2,
            'MUL': 4,
            'DIV': 10,
            'LW': 3,
            'SW': 2
        }
        
        # Reservation Stations (5 total: 3 Add/Sub, 2 Mult/Div)
        self.rs = [
            {'name': 'Add1', 'busy': False, 'op': None, 'vj': 0, 'vk': 0, 'qj': None, 'qk': None, 'dest': None, 'cycles': 0},
            {'name': 'Add2', 'busy': False, 'op': None, 'vj': 0, 'vk': 0, 'qj': None, 'qk': None, 'dest': None, 'cycles': 0},
            {'name': 'Add3', 'busy': False, 'op': None, 'vj': 0, 'vk': 0, 'qj': None, 'qk': None, 'dest': None, 'cycles': 0},
            {'name': 'Mult1', 'busy': False, 'op': None, 'vj': 0, 'vk': 0, 'qj': None, 'qk': None, 'dest': None, 'cycles': 0},
            {'name': 'Mult2', 'busy': False, 'op': None, 'vj': 0, 'vk': 0, 'qj': None, 'qk': None, 'dest': None, 'cycles': 0},
        ]
        
        # Reorder Buffer (8 entries)
        self.rob = [
            {'busy': False, 'instruction': None, 'estado': 'espera', 'value': None, 'dest': None}
            for _ in range(8)
        ]
        self.rob_head = 0  # Points to next instruction to commit
        self.rob_tail = 0  # Points to next free entry
        
        # Register File
        self.registers = [0] * numRegs
        
        # Register Status (tracks which ROB entry will write to each register)
        # None = register ready, int = ROB index that will write
        self.reg_status = [None] * numRegs
        
        # Simulation estado
        self.cycle = 0
        self.instructions = []
        self.pc = 0  # Program counter
        self.instructions_committed = 0
        self.bubble_cycles = 0
        self.flush_count = 0  # Count branch mispredictions
        self.log_messages = []  # Log of events for GUI
        
    def reset(self):
        """Reset simulator to initial estado."""
        self.__init__()
    
    def load_program(self, instructions):
        """
        Load program into simulator.
        
        Args:
            instructions: List of instruction dicts from parse_mips()
        """
        self.reset()
        self.instructions = [inst for inst in instructions if inst is not None]
        
        # Initialize registers with test values for demonstration
        self.registers[2] = 5   # R2 = 5
        self.registers[3] = 10  # R3 = 10
        self.registers[5] = 2   # R5 = 2
        self.registers[6] = 3   # R6 = 3
    
    def step(self):
        """
        Execute one clock cycle with 4 stages in CRITICAL order:
        1. Commit (in-order retirement, ONLY stage that writes registers)
        2. Write Result (broadcast to ROB, updates espera RS)
        3. Execute (decrement latencies)
        4. Issue (dispatch new instruction)
        """
        self.commit()
        self.write_result()
        self.execute()
        self.issue()
        self.cycle += 1
    
    def issue(self):
        """
        Stage 4: Issue - Dispatch next instruction to RS and ROB.
        Implements "Predict Not Taken" for branches.
        """
        # Check if there are more instructions to issue
        if self.pc >= len(self.instructions):
            return
        
        instruction = self.instructions[self.pc]
        op = instruction['op']
        
        # Find free RS based on operation type
        rs_index = None
        if op in ['ADD', 'SUB']:
            for i in range(3):  # Add1, Add2, Add3
                if not self.rs[i]['busy']:
                    rs_index = i
                    break
        elif op in ['MUL', 'DIV']:
            for i in range(3, 5):  # Mult1, Mult2
                if not self.rs[i]['busy']:
                    rs_index = i
                    break
        elif op in ['LW', 'SW']:
            # Use any Add station for memory ops
            for i in range(3):
                if not self.rs[i]['busy']:
                    rs_index = i
                    break
        elif op in ['BEQ', 'BNE']:
            # Branches use Add stations (for comparison)
            for i in range(3):
                if not self.rs[i]['busy']:
                    rs_index = i
                    break
        
        # Check if ROB has space
        if rs_index is None or self.rob[self.rob_tail]['busy']:
            self.bubble_cycles += 1
            return  # Structural hazard - stall
        
        # Allocate RS
        rs = self.rs[rs_index]
        rs['busy'] = True
        rs['op'] = op
        rs['cycles'] = self.LATENCIES.get(op, 1)  # Branches take 1 cycle
        rs['rob_index'] = self.rob_tail
        rs['pc_when_issued'] = self.pc  # Store PC for branch calculation
        
        # Read operands and handle dependencies
        dest_reg = int(instruction['dest'][1:])  # Extract register number from "R1"
        reg1_reg = int(instruction['reg1'][1:])
        reg2_reg = int(instruction['reg2'][1:])
        
        # Check reg1 dependency
        if self.reg_status[reg1_reg] is None:
            rs['vj'] = self.registers[reg1_reg]
            rs['qj'] = None
        else:
            rs['vj'] = None
            rs['qj'] = self.reg_status[reg1_reg]  # Wait for ROB entry
        
        # Check reg2 dependency
        if self.reg_status[reg2_reg] is None:
            rs['vk'] = self.registers[reg2_reg]
            rs['qk'] = None
        else:
            rs['vk'] = None
            rs['qk'] = self.reg_status[reg2_reg]  # Wait for ROB entry
        
        # Allocate ROB entry
        rob_entry = self.rob[self.rob_tail]
        rob_entry['busy'] = True
        rob_entry['instruction'] = instruction
        rob_entry['estado'] = 'executing'
        rob_entry['dest'] = dest_reg
        rob_entry['value'] = None
        rob_entry['should_branch'] = False  # For branch resolution
        rob_entry['target_pc'] = None  # Branch target
        
        # Mark destination register as espera for this ROB entry (skip for branches)
        if op not in ['BEQ', 'BNE']:
            self.reg_status[dest_reg] = self.rob_tail
        
        # Advance PC and ROB tail (Predict Not Taken - always increment)
        self.pc += 1
        self.rob_tail = (self.rob_tail + 1) % 8
        
        self.log_messages.append(f"Issued {op} at PC={self.pc-1}")
    
    def execute(self):
        """
        Stage 3: Execute - Decrement latency counters for RS with ready operands.
        """
        for rs in self.rs:
            if not rs['busy']:
                continue
            
            # Check if operands are ready
            if rs['qj'] is None and rs['qk'] is None:
                # Both operands ready, decrement cycles
                if rs['cycles'] > 0:
                    rs['cycles'] -= 1
    
    def write_result(self):
        """
        Stage 2: Write Result - Broadcast completed results to ROB and espera RS.
        CRITICAL: This does NOT write to registers[] - only Commit does that!
        """
        for rs in self.rs:
            if not rs['busy'] or rs['cycles'] > 0:
                continue
            
            # RS has completed execution
            op = rs['op']
            vj = rs['vj']
            vk = rs['vk']
            rob_index = rs['rob_index']
            
            # Calculate result or resolve branch
            if op == 'ADD':
                result = vj + vk
            elif op == 'SUB':
                result = vj - vk
            elif op == 'MUL':
                result = vj * vk
            elif op == 'DIV':
                result = vj // vk if vk != 0 else 0
            elif op in ['LW', 'SW']:
                result = vj + vk  # Address calculation (simplified)
            elif op == 'BEQ':
                # Resolve branch: should we take it?
                should_branch = (vj == vk)
                instruction = self.rob[rob_index]['instruction']
                pc_when_issued = rs['pc_when_issued']
                target_pc = pc_when_issued + 1 + instruction['offset']
                
                self.rob[rob_index]['should_branch'] = should_branch
                self.rob[rob_index]['target_pc'] = target_pc
                result = 0  # Branches don't produce values
                
                self.log_messages.append(f"BEQ resolved: {vj}=={vk}? {should_branch}, target PC={target_pc}")
            elif op == 'BNE':
                # Resolve branch: should we take it?
                should_branch = (vj != vk)
                instruction = self.rob[rob_index]['instruction']
                pc_when_issued = rs['pc_when_issued']
                target_pc = pc_when_issued + 1 + instruction['offset']
                
                self.rob[rob_index]['should_branch'] = should_branch
                self.rob[rob_index]['target_pc'] = target_pc
                result = 0  # Branches don't produce values
                
                self.log_messages.append(f"BNE resolved: {vj}!={vk}? {should_branch}, target PC={target_pc}")
            else:
                result = 0
            
            # Write to ROB (NOT to registers!)
            rob_index = rs['rob_index']
            self.rob[rob_index]['value'] = result
            self.rob[rob_index]['estado'] = 'ready'
            
            # Broadcast to espera RS - update operands
            for espera_rs in self.rs:
                if espera_rs['qj'] == rob_index:
                    espera_rs['vj'] = result
                    espera_rs['qj'] = None
                if espera_rs['qk'] == rob_index:
                    espera_rs['vk'] = result
                    espera_rs['qk'] = None
            
            # Clear RS
            rs['busy'] = False
            rs['op'] = None
            rs['vj'] = 0
            rs['vk'] = 0
            rs['qj'] = None
            rs['qk'] = None
            rs['dest'] = None
            rs['cycles'] = 0
    
    def commit(self):
        """
        Stage 1: Commit - Retire instruction at ROB head in program order.
        CRITICAL: This is the ONLY stage that writes to registers[]!
        Also handles branch misprediction detection and FLUSH.
        """
        rob_entry = self.rob[self.rob_head]
        
        # Check if head is ready to commit
        if not rob_entry['busy'] or rob_entry['estado'] != 'ready':
            return
        
        instruction = rob_entry['instruction']
        op = instruction['op'] if instruction else None
        
        # Handle branch commit - check for misprediction
        if op in ['BEQ', 'BNE']:
            predicted_not_taken = True  # Our strategy: always predict not taken
            actual_should_branch = rob_entry['should_branch']
            
            # Misprediction occurs when branch is actually taken (we predicted not taken)
            if actual_should_branch:  # Branch was taken, but we predicted not taken
                # MISPREDICTION! Need to flush and redirect
                target_pc = rob_entry['target_pc']
                self.log_messages.append(f"🔥 FLUSH! Branch mispredicted, jumping to PC={target_pc}")
                self.flush(target_pc)
                self.flush_count += 1
            
            # Commit the branch (clear ROB entry)
            rob_entry['busy'] = False
            rob_entry['instruction'] = None
            rob_entry['estado'] = 'espera'
            rob_entry['value'] = None
            rob_entry['dest'] = None
            
            self.rob_head = (self.rob_head + 1) % 8
            self.instructions_committed += 1
            self.log_messages.append(f"Committed {op}")
            return
        
        # Normal instruction commit (non-branch)
        dest_reg = rob_entry['dest']
        self.registers[dest_reg] = rob_entry['value']
        
        # Clear register status if this ROB entry was the one writing to it
        if self.reg_status[dest_reg] == self.rob_head:
            self.reg_status[dest_reg] = None
        
        # Clear ROB entry
        rob_entry['busy'] = False
        rob_entry['instruction'] = None
        rob_entry['estado'] = 'espera'
        rob_entry['value'] = None
        rob_entry['dest'] = None
        
        # Advance head and track committed instructions
        self.rob_head = (self.rob_head + 1) % 8
        self.instructions_committed += 1
        self.log_messages.append(f"Committed {op}")
    
    def flush(self, correct_pc):
        """
        CRITICAL: Flush pipeline after branch misprediction.
        Clears all speculative work and redirects to correct PC.
        
        Args:
            correct_pc: The correct program counter to jump to
        """
        # 1. Clear all Reservation Stations (discard speculative work)
        for rs in self.rs:
            rs['busy'] = False
            rs['op'] = None
            rs['vj'] = 0
            rs['vk'] = 0
            rs['qj'] = None
            rs['qk'] = None
            rs['dest'] = None
            rs['cycles'] = 0
        
        # 2. Clear all ROB entries AFTER the head (keep head, it's the branch committing)
        # Start from the next entry after head
        tail_index = self.rob_head
        for i in range(8):
            if i != self.rob_head:  # Don't clear the branch itself
                self.rob[i]['busy'] = False
                self.rob[i]['instruction'] = None
                self.rob[i]['estado'] = 'espera'
                self.rob[i]['value'] = None
                self.rob[i]['dest'] = None
        
        # 3. Reset tail to right after head
        self.rob_tail = (self.rob_head + 1) % 8
        
        # 4. Clear all register status (no register is espera anymore)
        for i in range(numRegs):
            self.reg_status[i] = None
        
        # 5. Redirect PC to correct branch target
        self.pc = correct_pc
        
        self.log_messages.append(f"Pipeline flushed, PC redirected to {correct_pc}")
    
    def is_complete(self):
        """
        Check if simulation is complete.
        Complete when: PC past program end AND ROB is empty (all issued instructions committed).
        """
        # Check if PC is past the program
        pc_done = self.pc >= len(self.instructions)
        
        # Check if ROB is empty (nothing left to commit)
        rob_empty = all(not entry['busy'] for entry in self.rob)
        
        return pc_done and rob_empty
    
    def get_metrics(self):
        """Return simulation metrics."""
        ipc = self.instructions_committed / self.cycle if self.cycle > 0 else 0
        return {
            'cycles': self.cycle,
            'instructions': self.instructions_committed,
            'ipc': ipc,
            'bubbles': self.bubble_cycles,
            'flushes': self.flush_count
        }