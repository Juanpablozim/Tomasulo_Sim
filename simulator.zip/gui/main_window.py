from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
    QPushButton, QLabel, QTableWidget, QTableWidgetItem,
    QFileDialog, QGridLayout, QHeaderView, QTextEdit
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor, QFont
import time
import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

from src.simulator.tomasulo_engine import TomasuloEngine
from src.simulator.instruction import parse_mips


class MainWindow(QMainWindow):
    """
    Simple PyQt6 GUI for Tomasulo simulator.
    Shows RS, ROB, registers with step-by-step execution.
    """
    
    def __init__(self):
        super().__init__()
        self.engine = TomasuloEngine()
        self.current_program_path = None
        self.init_ui()
    
    def init_ui(self):
        """Initialize user interface."""
        self.setWindowTitle("Simulador Tomasulo - Trabalho AC3")
        self.setGeometry(100, 100, 1200, 800)
        
        # Central widget
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)
        
        # === CONTROL BUTTONS ===
        btn_layout = QHBoxLayout()
        
        self.btn_load = QPushButton("📂 Carregar Programa")
        self.btn_step = QPushButton("▶️ Step")
        self.btn_run = QPushButton("⏩ Run")
        self.btn_reset = QPushButton("🔄 Reset")
        
        self.btn_load.clicked.connect(self.load_program)
        self.btn_step.clicked.connect(self.step)
        self.btn_run.clicked.connect(self.run)
        self.btn_reset.clicked.connect(self.reset)
        
        # Style buttons
        btn_style = """
            QPushButton {
                padding: 8px 16px;
                font-size: 14px;
                font-weight: bold;
            }
        """
        for btn in [self.btn_load, self.btn_step, self.btn_run, self.btn_reset]:
            btn.setStyleSheet(btn_style)
        
        btn_layout.addWidget(self.btn_load)
        btn_layout.addWidget(self.btn_step)
        btn_layout.addWidget(self.btn_run)
        btn_layout.addWidget(self.btn_reset)
        btn_layout.addStretch()
        
        main_layout.addLayout(btn_layout)
        
        # === METRICS ===
        metrics_layout = QHBoxLayout()
        
        self.lbl_cycle = QLabel("Ciclo: 0")
        self.lbl_ipc = QLabel("IPC: 0.00")
        self.lbl_bubbles = QLabel("Bolhas: 0")
        self.lbl_flushes = QLabel("Flushes: 0")
        
        metrics_font = QFont("Arial", 12, QFont.Weight.Bold)
        for lbl in [self.lbl_cycle, self.lbl_ipc, self.lbl_bubbles, self.lbl_flushes]:
            lbl.setFont(metrics_font)
            lbl.setStyleSheet("padding: 8px; background-color: #f0f0f0; border-radius: 4px;")
        
        metrics_layout.addWidget(self.lbl_cycle)
        metrics_layout.addWidget(self.lbl_ipc)
        metrics_layout.addWidget(self.lbl_bubbles)
        metrics_layout.addWidget(self.lbl_flushes)
        metrics_layout.addStretch()
        
        main_layout.addLayout(metrics_layout)
        
        # === RESERVATION STATIONS TABLE ===
        main_layout.addWidget(QLabel("🔧 Reservation Stations:", styleSheet="font-size: 14px; font-weight: bold; margin-top: 10px;"))
        
        self.rs_table = QTableWidget(5, 5)
        self.rs_table.setHorizontalHeaderLabels(["Nome", "Busy", "Op", "Operandos", "Ciclos"])
        self.rs_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.rs_table.setMaximumHeight(200)
        
        main_layout.addWidget(self.rs_table)
        
        # === REORDER BUFFER TABLE ===
        main_layout.addWidget(QLabel("📋 Reorder Buffer (ROB):", styleSheet="font-size: 14px; font-weight: bold; margin-top: 10px;"))
        
        self.rob_table = QTableWidget(8, 5)
        self.rob_table.setHorizontalHeaderLabels(["#", "Busy", "Instrução", "Estado", "Value"])
        self.rob_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.rob_table.setMaximumHeight(280)
        
        main_layout.addWidget(self.rob_table)
        
        # === REGISTERS GRID ===
        main_layout.addWidget(QLabel("💾 Registradores (R0-R15):", styleSheet="font-size: 14px; font-weight: bold; margin-top: 10px;"))
        
        reg_grid = QGridLayout()
        self.reg_labels = []
        
        mono_font = QFont("Courier", 11)
        for i in range(16):
            lbl = QLabel(f"R{i}=0")
            lbl.setFont(mono_font)
            lbl.setStyleSheet("padding: 4px; background-color: #f9f9f9; border: 1px solid #ddd;")
            lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.reg_labels.append(lbl)
            reg_grid.addWidget(lbl, i // 4, i % 4)
        
        main_layout.addLayout(reg_grid)
        
        # === CONSOLE LOG ===
        main_layout.addWidget(QLabel("📜 Console de Eventos:", styleSheet="font-size: 14px; font-weight: bold; margin-top: 10px;"))
        
        self.log_console = QTextEdit()
        self.log_console.setReadOnly(True)
        self.log_console.setMaximumHeight(150)
        self.log_console.setStyleSheet("""
            QTextEdit {
                font-family: Courier;
                font-size: 11px;
                background-color: #1e1e1e;
                color: #d4d4d4;
                border: 2px solid #555;
            }
        """)
        self.log_console.setPlainText("Aguardando programa...\n")
        
        main_layout.addWidget(self.log_console)
        
        # Initial UI update
        self.update_ui()
    
    def load_program(self):
        """Load MIPS program from file."""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Carregar Programa MIPS",
            "examples",
            "Assembly Files (*.asm);;All Files (*)"
        )
        
        if not file_path:
            return
        
        try:
            with open(file_path, 'r') as f:
                lines = f.readlines()
            
            program = [parse_mips(line) for line in lines]
            program = [inst for inst in program if inst is not None]
            
            if not program:
                self.statusBar().showMessage("❌ Nenhuma instrução válida encontrada!", 3000)
                return
            
            self.engine.load_program(program)
            self.current_program_path = file_path
            self.update_ui()
            
            self.statusBar().showMessage(f"✅ Programa carregado: {len(program)} instruções", 3000)
        
        except Exception as e:
            self.statusBar().showMessage(f"❌ Erro ao carregar: {str(e)}", 5000)
    
    def step(self):
        """Execute one cycle."""
        if not self.engine.instructions:
            self.statusBar().showMessage("⚠️ Nenhum programa carregado!", 3000)
            return
        
        if self.engine.is_complete():
            self.statusBar().showMessage("✅ Simulação completa!", 3000)
            return
        
        self.engine.step()
        self.update_ui()
    
    def run(self):
        """Execute until completion with delay for visualization."""
        if not self.engine.instructions:
            self.statusBar().showMessage("⚠️ Nenhum programa carregado!", 3000)
            return
        
        if self.engine.is_complete():
            self.statusBar().showMessage("✅ Simulação já completa!", 3000)
            return
        
        max_cycles = 100
        cycles = 0
        
        while not self.engine.is_complete() and cycles < max_cycles:
            self.engine.step()
            self.update_ui()
            
            # Small delay for visualization
            time.sleep(0.3)
            
            # Process events to keep UI responsive
            from PyQt6.QtWidgets import QApplication
            QApplication.processEvents()
            
            cycles += 1
        
        if cycles >= max_cycles:
            self.statusBar().showMessage("⚠️ Limite de ciclos atingido!", 3000)
        else:
            self.statusBar().showMessage("✅ Simulação completa!", 3000)
    
    def reset(self):
        """Reset simulation with current program."""
        if self.current_program_path:
            # Reload same program
            with open(self.current_program_path, 'r') as f:
                lines = f.readlines()
            
            program = [parse_mips(line) for line in lines]
            program = [inst for inst in program if inst is not None]
            
            self.engine.load_program(program)
            self.update_ui()
            
            self.statusBar().showMessage("🔄 Simulação resetada", 2000)
        else:
            self.statusBar().showMessage("⚠️ Nenhum programa carregado para resetar!", 3000)
    
    def update_ui(self):
        """Update all UI elements from engine state."""
        # === UPDATE METRICS ===
        metrics = self.engine.get_metrics()
        self.lbl_cycle.setText(f"Ciclo: {metrics['cycles']}")
        self.lbl_ipc.setText(f"IPC: {metrics['ipc']:.2f}")
        self.lbl_bubbles.setText(f"Bolhas: {metrics['bubbles']}")
        self.lbl_flushes.setText(f"Flushes: {metrics['flushes']}")
        
        # === UPDATE RS TABLE ===
        for i, rs in enumerate(self.engine.rs):
            # Name
            self.rs_table.setItem(i, 0, QTableWidgetItem(rs['name']))
            
            # Busy
            busy_text = "Sim" if rs['busy'] else "Não"
            self.rs_table.setItem(i, 1, QTableWidgetItem(busy_text))
            
            # Op
            op_text = rs['op'] if rs['op'] else "-"
            self.rs_table.setItem(i, 2, QTableWidgetItem(op_text))
            
            # Operands
            if rs['busy']:
                vj_text = str(rs['vj']) if rs['qj'] is None else f"ROB#{rs['qj']}"
                vk_text = str(rs['vk']) if rs['qk'] is None else f"ROB#{rs['qk']}"
                operands = f"{vj_text}, {vk_text}"
            else:
                operands = "-"
            self.rs_table.setItem(i, 3, QTableWidgetItem(operands))
            
            # Cycles
            cycles_text = str(rs['cycles']) if rs['busy'] else "-"
            self.rs_table.setItem(i, 4, QTableWidgetItem(cycles_text))
            
            # Color: Yellow if busy
            bg_color = QColor("#FFFFCC") if rs['busy'] else QColor("#FFFFFF")
            for col in range(5):
                self.rs_table.item(i, col).setBackground(bg_color)
                self.rs_table.item(i, col).setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        
        # === UPDATE ROB TABLE ===
        for i in range(8):
            entry = self.engine.rob[i]
            
            # Determine badge and color
            badge = ""
            if i == self.engine.rob_head:
                badge = "[HEAD] "
                bg_color = QColor("#90EE90")  # Light green
            elif i == self.engine.rob_tail:
                badge = "[TAIL] "
                bg_color = QColor("#ADD8E6")  # Light blue
            elif entry['busy'] and entry['estado'] == 'ready':
                bg_color = QColor("#FFFFE0")  # Light yellow (ready for commit)
            elif entry['busy']:
                bg_color = QColor("#D3D3D3")  # Light gray (executing)
            else:
                bg_color = QColor("#FFFFFF")  # White (free)
            
            # # Column
            self.rob_table.setItem(i, 0, QTableWidgetItem(f"{badge}{i}"))
            
            # Busy
            busy_text = "Sim" if entry['busy'] else "Não"
            self.rob_table.setItem(i, 1, QTableWidgetItem(busy_text))
            
            # Instruction
            if entry['instruction']:
                inst = entry['instruction']
                inst_text = f"{inst['op']} {inst['dest']} {inst['reg1']} {inst['reg2']}"
            else:
                inst_text = "-"
            self.rob_table.setItem(i, 2, QTableWidgetItem(inst_text))
            
            # State
            state_text = entry['estado'].capitalize() if entry['busy'] else "-"
            self.rob_table.setItem(i, 3, QTableWidgetItem(state_text))
            
            # Value
            value_text = str(entry['value']) if entry['value'] is not None else "-"
            self.rob_table.setItem(i, 4, QTableWidgetItem(value_text))
            
            # Apply background color to all columns
            for col in range(5):
                self.rob_table.item(i, col).setBackground(bg_color)
                self.rob_table.item(i, col).setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        
        # === UPDATE REGISTERS ===
        for i in range(16):
            val = self.engine.registers[i]
            qi = self.engine.reg_status[i]
            
            if qi is not None:
                text = f"R{i}={val} (ROB#{qi})"
                color = "red"  # Waiting for result
            else:
                text = f"R{i}={val}"
                color = "black"  # Ready
            
            self.reg_labels[i].setText(text)
            self.reg_labels[i].setStyleSheet(
                f"padding: 4px; background-color: #f9f9f9; border: 1px solid #ddd; color: {color};"
            )
        
        # === UPDATE LOG CONSOLE ===
        if self.engine.log_messages:
            # Show last 20 messages
            recent_logs = self.engine.log_messages[-20:]
            log_text = "\n".join([f"[Ciclo {self.engine.cycle}] {msg}" for msg in recent_logs])
            self.log_console.setPlainText(log_text)
            # Auto-scroll to bottom
            self.log_console.verticalScrollBar().setValue(
                self.log_console.verticalScrollBar().maximum()
            )
